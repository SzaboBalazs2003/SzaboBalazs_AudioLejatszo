﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Threading;

namespace Audio_lejátszó
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += timer_Tick;
            timer.Start();
        }
        int sorok = 0;
        string[] zenek, utak;
        bool playing;
        bool dragging = false;
        bool end = false, listl = false;

        private void timer_Tick(object sender, EventArgs e)
        {
            if ((mplayer.Source != null) && (mplayer.NaturalDuration.HasTimeSpan) && (!dragging))
            {
                halad.Minimum = 0;
                halad.Maximum = mplayer.NaturalDuration.TimeSpan.TotalSeconds;
                halad.Value = mplayer.Position.TotalSeconds;
            }
        }
        private void play_Click(object sender, RoutedEventArgs e)
        {
            if (playing == false)
            {
                mplayer.Play();
                playing = true;
            }
        }
        private void halad_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            time.Content = TimeSpan.FromSeconds(halad.Value).ToString(@"hh\:mm\:ss");
            if (end==true)
            {
                if (mplayer.Position == mplayer.NaturalDuration)
                {
                    mplayer.Stop();
                    mplayer.Play();
                }
            }
            else if (listl==true)
            {
                if (mplayer.Position == mplayer.NaturalDuration)
                {
                    int index = lista.SelectedIndex;
                    if (!(lista.SelectedIndex == sorok - 1))
                    {
                        if (playing == true)
                        {
                            mplayer.Stop();
                            mplayer.Source = new Uri(utak[index + 1], UriKind.Absolute);
                            lista.SelectedIndex += 1;
                            mplayer.Play();
                        }
                        else
                        {
                            mplayer.Source = new Uri(utak[index + 1], UriKind.Absolute);
                            lista.SelectedIndex += 1;
                            mplayer.Play();
                        }
                    }
                    else
                    {
                        if (playing == true)
                        {
                            mplayer.Stop();
                            mplayer.Source = new Uri(utak[0], UriKind.Absolute);
                            lista.SelectedIndex = 0;
                            mplayer.Play();
                        }
                        else
                        {
                            mplayer.Source = new Uri(utak[0], UriKind.Absolute);
                            lista.SelectedIndex = 0;
                            mplayer.Play();
                        }
                    }
                }
            }
        }
        private void lista_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int szam = lista.SelectedIndex;
            string ut = utak[szam];
            mplayer.Source = new Uri(ut, UriKind.Absolute);
            playing = false;
            time.Content= mplayer.Position;
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog mentes = new SaveFileDialog();
                mentes.Filter = "Szöveges állományok (*.txt)|*.txt|Minden állomány (*.*)|*.*";
                mentes.ShowDialog();
                StreamWriter sw = new StreamWriter(mentes.FileName);
                for (int i = 0; i < zenek.Length; i++)
                {
                    sw.WriteLine(zenek[i] + "%" + utak[i]);
                }
                sw.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Nem jó az elérési út.");
            }
        }

        private void load_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog betoltes = new OpenFileDialog();
                betoltes.Filter = "Szöveges állományok (.txt)|*.txt|Minden állomány (*.*)|*.*";
                betoltes.ShowDialog();
                StreamReader stream = new StreamReader(betoltes.FileName);
                while (!stream.EndOfStream)
                {
                    stream.ReadLine();
                    sorok++;
                }
                stream.Close();
                StreamReader sr = new StreamReader(betoltes.FileName);
                zenek = new string[sorok];
                utak = new string[sorok];
                while (!sr.EndOfStream)
                {
                    for (int i = 0; i < sorok; i++)
                    {
                        string sor = sr.ReadLine();
                        string[] resz = sor.Split('%');
                        zenek[i] = resz[0];
                        utak[i] = resz[1];
                        lista.Items.Add(zenek[i]);
                    }
                }
                sr.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Nem megfelelő a mentés formátuma. Vagy nem jó az elérési út.");
            }
        }

        private void pause_Click(object sender, RoutedEventArgs e)
        {
            mplayer.Pause();
            playing = false;
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double hangero = volume.Value;
            mplayer.Volume = hangero;
        }

        private void stop_Click(object sender, RoutedEventArgs e)
        {
            mplayer.Stop();
            playing = false;
        }

        private void next_Click(object sender, RoutedEventArgs e)
        {
            int index = lista.SelectedIndex;
            if (!(lista.SelectedIndex == sorok-1))
            {
                if (playing == true)
                {
                    mplayer.Stop();
                    mplayer.Source = new Uri(utak[index + 1], UriKind.Absolute);
                    lista.SelectedIndex += 1;
                    mplayer.Play();
                }
                else
                {
                    mplayer.Source = new Uri(utak[index + 1], UriKind.Absolute);
                    lista.SelectedIndex += 1;
                    mplayer.Play();
                }
            }
            else
            {
                if (playing == true)
                {
                    mplayer.Stop();
                    mplayer.Source = new Uri(utak[0], UriKind.Absolute);
                    lista.SelectedIndex = 0;
                    mplayer.Play();
                }
                else
                {
                    mplayer.Source = new Uri(utak[0], UriKind.Absolute);
                    lista.SelectedIndex = 0;
                    mplayer.Play();
                }
            }
        }

        private void Prev_Click(object sender, RoutedEventArgs e)
        {
            int index = lista.SelectedIndex;
            if (!(lista.SelectedIndex==0))
            {
                if (playing == true)
                {
                    mplayer.Stop();
                    mplayer.Source = new Uri(utak[index - 1], UriKind.Absolute);
                    lista.SelectedIndex -= 1;
                    mplayer.Play();
                }
                else
                {
                    mplayer.Source = new Uri(utak[index - 1], UriKind.Absolute);
                    lista.SelectedIndex -= 1;
                    mplayer.Play();
                }
            }
            else
            {
                if (playing == true)
                {
                    mplayer.Stop();
                    mplayer.Source = new Uri(utak[sorok-1], UriKind.Absolute);
                    lista.SelectedIndex = sorok-1;
                    mplayer.Play();
                }
                else
                {
                    mplayer.Source = new Uri(utak[sorok-1], UriKind.Absolute);
                    lista.SelectedIndex = sorok - 1;
                    mplayer.Play();
                }
            }
        }

        private void halad_DragOver(object sender, DragEventArgs e)
        {
            dragging = false;
            time.Content = TimeSpan.FromSeconds(halad.Value).ToString(@"hh\:mm\:ss");
        }

        private void halad_DragEnter(object sender, DragEventArgs e)
        {
            dragging = true;
        }

        private void vegtel_Click(object sender, RoutedEventArgs e)
        {
            if (end == false)
            {
                end = true;
            }
            else
                end = false;
        }

        private void loop_Click(object sender, RoutedEventArgs e)
        {
            if (listl == false)
            {
                listl = true;
            }
            else
                listl = false;
        }

        private void files_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog kiv = new OpenFileDialog();
            kiv.Filter = "Media files (*.mp3) | *.mp3 | All files (*.*) | *.*";
            kiv.Title = "Válasszon zenét";
            kiv.Multiselect = true;
            kiv.ShowDialog();
            zenek = kiv.SafeFileNames;
            utak = kiv.FileNames;
            for (int i = 0; i < zenek.Length; i++)
            {
                lista.Items.Add(zenek[i]);
            }
            sorok = lista.Items.Count;
        }
    }
}
